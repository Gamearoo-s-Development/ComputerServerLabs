# SUID Awareness (read-only)

**Category:** Linux Permissions  
**Difficulty:** Hard  
**Type:** Bundled (ships with app)  
**Estimated time:** 30 minutes

## Overview

Practice **risk identification** inside an isolated Docker lab target. No host access required.

## Objectives

1. Read `~/README.txt`
2. Create the read and completion markers described in the briefing
3. Run **Check** in the app

## Safety

- Educational use only
- Do not run destructive commands
- Container is ephemeral and offline-capable once built

## Files

- `lab.json` — lab definition
- `lab-setup.sh` — container bootstrap (bundled labs)
- `Dockerfile` — image build (bundled labs)
